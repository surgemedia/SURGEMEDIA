<?php 
/*=========================================
=            Custom Menu Register         =
=========================================*/

function register_my_menu() {
  register_nav_menu('footer-menu',__( 'Footer Menu' ));
}
add_action( 'init', 'register_my_menu' );