<script type='text/javascript'>
    var __ac = {};
    __ac.uid = "7722b04cef405161ff744846e091d77b";
    __ac.server = "secure.chatrify.com";

    (function() {
      var ac = document.createElement('script'); 
      ac.type = 'text/javascript'; 
      ac.async = true;
      ac.src = 'https://cdn.chatrify.com/go.js';
      var s = document.getElementsByTagName('script')[0]; 
      s.parentNode.insertBefore(ac, s);
    })();
</script>
