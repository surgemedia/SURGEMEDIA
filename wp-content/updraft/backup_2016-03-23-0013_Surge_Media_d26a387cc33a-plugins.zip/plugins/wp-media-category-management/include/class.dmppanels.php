<?php

class DMPPanelWPMCMMain       extends DebugMyPluginPanel {
    function __construct() {
        parent::__construct('WP MCM');
    }
}
