<article class="item <?php echo $active; ?>">
    <div class="container">
        <hgroup class="carousel-caption">
        <h1><a href="<?php echo $carousel[$i]['link_location']; ?>"><?php echo $carousel[$i]['title']; ?></a></h1>
        <h2><?php echo $carousel[$i]['subtitle_line_one']; ?> <br><?php echo $carousel[$i]['subtitle_line_two'];  ?></h2>
        </hgroup>
    </div>
</article>