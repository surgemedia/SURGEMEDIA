=== CodePen oEmbed ===
Author URI: http://pippinsplugins.com
Author: Pippin Williamson
Contributors: mordauk, norcross
Donate link: http://pippinsplugins.com/support-the-site
Tags: CodePen.io, oEmbed, CodePen
Requires at least: 3.7
Tested up to: 4.1
Stable tag: 1.0.0

Add CodePen to the available oEmbed providers

== Description ==

Add CodePen to the available oEmbed providers

If you're blogging in Markdown via the WP-Markdown plugin, oEmbed doesn't work, but Jetpack now enabled Markdown blogging and it does work through that.

oEmbed only works through post/page content in WordPress, but you can bring it to comments as well:

You can read more about it [here](http://blog.codepen.io/2014/04/03/oembed/ "CodePen announces oEmbed support") for additional information

== Installation ==

1. Upload `codepen-oembed` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. That's it

== Frequently Asked Questions ==

= What is CodePen? =

The answer to all your problems. All of them.

== Screenshots ==

1. An example

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release

